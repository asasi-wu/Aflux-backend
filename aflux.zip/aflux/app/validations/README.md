# App Validations

The libraries in this directory are responsible
for validating queries and raising the proper exceptions.
