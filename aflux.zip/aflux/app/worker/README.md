# Async Workers
The libraries in this directory are responsible
for performing offline tasks, which don't require
the user to be waiting for.
