# Application Models

This classes are responsible for interacting
with the database. No authentication or business
logic is performed here.
