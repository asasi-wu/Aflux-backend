"""
Security libraries.

These classes are responsible for ensuring
a certain degree of security in the app.
"""
