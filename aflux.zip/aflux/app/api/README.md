# Application API
These classes are only responsible for authenticating
the request and handling exceptions on behalf of the client.
